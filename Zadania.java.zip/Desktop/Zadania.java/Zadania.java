package tablice;

import java.util.Random;

public class Zadania {

	private static Random random = new Random();

	// Generator int przyjmujacy min - max parametry
	public static int generator(int min, int max) {
		return random.nextInt((max - min) + 1) + min;
	}

	// Funkcja pomocniczna do drukowania tablicy
	public static void printArray(int[][] array) {
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				System.out.printf("%3s", array[i][j]);

			}
			System.out.println();
		}

	}

	// Funkcja pomocniczna sprawdza czy liczba rzedów 1 tablicy = liczbie rzędów 2
	// tablic oraz czy dlugosci kolumn sa rowne
	public static boolean equalSize(int[][] array1, int[][] array2) {
		if (array1.length == array2.length) {
			for (int i = 0; i < array1.length; i++) {
				for (int j = 0; j < array1[i].length; j++) {
					if (array1[i].length != array2[i].length) {
						return false;
					}
				}
			}
			return true;
		} else {
			return false;
		}

	}

	public static int[][] zadanie1(int n, int min, int max) {
		int[][] array = new int[n][n];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				array[i][j] = generator(min, max);
			}
		}
		return array;
	}

	public static int[][] zadanie2(int[][] array1, int[][] array2) {
		if (equalSize(array1, array2)) {
//			Z zalozenia zadania wiemy, ze tablica jest kwadratowa i liczba kolumn = liczbie rzedow
			int[][] sum = new int[array1.length][array1.length];
			for (int i = 0; i < array1.length; i++) {
				for (int j = 0; j < array1[i].length; j++) {
					sum[i][j] = array1[i][j] + array2[i][j];
				}
			}
			return sum;
		} else {
			System.out.println("Nie mozna dodac, rozny rozmiar tablic!!!");
			return new int[0][0];
		}
	}

	public static void main(String[] args) {
		System.out.println("ZADANIE 1" + System.lineSeparator());
		int n = 5;
		System.out.println("Dla n = " + n);
		int[][] zadanie1 = zadanie1(5, 0, 9);
		printArray(zadanie1);
		System.out.println(System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + "ZADANIE 2"
				+ System.lineSeparator());
		System.out.println("Tablica pierwsza: ");
		int[][] array1 = zadanie1(5, 0, 9);
		printArray(array1);
		System.out.println();
		System.out.println("Tablica druga: ");
		int[][] array2 = zadanie1(5, 0, 9);
		printArray(array2);
		System.out.println();
		System.out.println("Suma: ");
		int[][] sum = zadanie2(array1, array2);
		printArray(sum);

	}

}
