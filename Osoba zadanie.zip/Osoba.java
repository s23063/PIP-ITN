import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Objects;
import java.util.stream.Stream;

public class Osoba {

    private int ID;
    private String imie;
    private String nazwisko;
    private String adresMail;
    private String krajZamieszkania;

    private static int obecneID = 1;


    public Osoba(String imie, String nazwisko, String adresMail, String krajZamieszkania) {
        setID(Osoba.obecneID++);
        setImie(imie);
        setNazwisko(nazwisko);
        setAdresMail(adresMail);
        setKrajZamieszkania(krajZamieszkania);
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        if(!Objects.isNull(imie) && !imie.isEmpty()){
            this.imie = imie;
        }

    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        if(!Objects.isNull(nazwisko) && !nazwisko.isEmpty()){
            this.nazwisko = nazwisko;
        }

    }

    public String getAdresMail() {
        return adresMail;
    }

    public void setAdresMail(String adresMail) {
        if(!Objects.isNull(adresMail) && !adresMail.isEmpty()){
            this.adresMail = adresMail;
        }
    }

    public String getKrajZamieszkania() {
        return krajZamieszkania;
    }

    public void setKrajZamieszkania(String krajZamieszkania) {
        if(!Objects.isNull(krajZamieszkania) && !krajZamieszkania.isEmpty()){
            this.krajZamieszkania = krajZamieszkania;
        }
    }

    @Override
    public String toString() {
        return "Osoba{" +
                "ID=" + ID +
                ", imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", adresMail='" + adresMail + '\'' +
                ", krajZamieszkania='" + krajZamieszkania + '\'' +
                '}';
    }

    public static void main(String[] args) {
        BufferedReader reader;
        Osoba[] osoby;
        int liczbaLinii;

        try (Stream<String> stream = Files.lines(Paths.get("data.txt"),StandardCharsets.UTF_8)) {
            liczbaLinii = (int) stream.count();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        try {
            reader = new BufferedReader(new FileReader("data.txt"));
            String line = reader.readLine();

             osoby = new Osoba[liczbaLinii];
            int i = 0;
            while (line != null) {
                String[] split = line.split(",");
                String[] imieINazwisko = split[0].split(" ");
                osoby[i] = new Osoba(imieINazwisko[0], imieINazwisko[1], split[1], split[2]);

                line = reader.readLine();
                i++;
            }

            reader.close();
            for (Osoba o: osoby
            ) {
                System.out.println(o);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
