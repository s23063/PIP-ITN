package com.company;

public class Main {
    public static int F(int n) {  if(n == 0) {    return 0;
    }  if(n == 1) {    return 1;
    }  else {    return F(n-1) + F(n-2);
    }}
    public static void main(String[] args) {
        int n = 6;
        System.out.println(F(n));

    }
}
