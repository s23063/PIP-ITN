package zadanka;

import java.util.Scanner;

public class Zadanie1 {

	public void printNumber(int n) {
		if (n > 0) {
			for (int i = 0; i <= n; i++) {
				System.out.println(i);
			}
		} else {
			for (int i = 0; i >= n; i--) {
				System.out.println(i);
			}
		}

	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int input;
		System.out.println("Wprowadź liczbę: ");
		input = scanner.nextInt();

		Zadanie1 zadanie1 = new Zadanie1();
		zadanie1.printNumber(input);

	}

}
