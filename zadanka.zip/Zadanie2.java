package zadanka;

import java.util.Random;
import java.util.Scanner;

public class Zadanie2 {

	private Random random = new Random();

	public void randomNumberA(int n) {
		int counter = 0;
		while (counter < n) {
			System.out.println(random.nextInt());
			counter++;
		}
	}

	public void randomNumberB(int n) {
		int counter = 0;
		do {
			System.out.println(random.nextInt());
			counter++;
		} while (counter < n);

	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int input;
		System.out.print("Wprowadź liczbę: ");
		input = scanner.nextInt();

		Zadanie2 zadanie2 = new Zadanie2();
		System.out.println("Losowe numery pętla while");
		zadanie2.randomNumberA(input);
		System.out.println("Losowe numery pętla do while");
		zadanie2.randomNumberB(input);

	}

}
