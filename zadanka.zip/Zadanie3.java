package zadanka;

import java.util.Scanner;

public class Zadanie3 {

	public void print5(int n) {
		for (int i = 0; i < n; i++) {

			for (int j = 0; j <= i; j++) {

				System.out.print("* ");
			}

			System.out.println();
		}

	}

	public void print8(int n) {
		for (int i = 0; i < n - 2; i++) {
			for (int j = 0; j < n - i - 2; j++)
				System.out.print(" ");
			for (int k = 0; k < (2 * i + 1); k++)
				System.out.print("*");
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int input;
		System.out.print("Wprowadź liczbę: ");
		input = scanner.nextInt();

		Zadanie3 zadanie3 = new Zadanie3();
		System.out.println("Za 5pkt");
		zadanie3.print5(5);
		System.out.println("Za 8pkt");
		zadanie3.print8(5);

	}

}
